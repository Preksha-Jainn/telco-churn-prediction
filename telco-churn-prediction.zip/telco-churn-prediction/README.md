# Telecom Customer Churn Prediction

Predicting which telecom customers are about to leave, and ranking them by how much revenue is at risk, so a retention team knows whom to call first.

**Team Signal Over Noise (Group 6), IIT Mandi**

---

## The problem

A telecom company loses about 1 in 4 customers (26.5% churn). Calling every customer is expensive, so the company needs to know:

1. **Who** is likely to leave?
2. **Who is worth saving**, considering what each customer is worth?

## Dataset

[IBM Telco Customer Churn](https://www.ibm.com/docs/en/cognos-analytics/12.0.0?topic=samples-telco-customer-churn) sample: **7,043 customers × 50 columns** (demographics, location, services, contract, billing, CLTV).

| File | What it is |
|---|---|
| `data/telco.csv` | Raw data |
| `data/telco_features_88cols.csv` | Cleaned data with the 49 engineered features (88 columns) |
| `docs/data_dictionary.xlsx` | Meaning and construction of each of the 88 columns |

## Approach

1. **Cleaning and leakage removal**: dropped columns that are only known *after* a customer leaves (Churn Score, Satisfaction Score, Customer Status, Churn Category, Churn Reason) and high-cardinality location IDs (City, Zip Code). Latitude/Longitude kept.
2. **Train/test split**: stratified 80/20 (`random_state=42`) done **before** any statistics are learned, so the test set stays unseen.
3. **Feature engineering**: 49 new features (tenure bands, charge per tenure, price vs. peer median by internet type, service counts, contract × internet combinations, etc.). Medians are computed on training rows only.
4. **Feature selection**: Information Value (IV ≥ 0.02) and correlation filter (|r| < 0.90), giving **55 of 82** features.
5. **Model comparison**: 12 models with 5-fold stratified cross-validation, scored on **PR-AUC** (better than accuracy for imbalanced classes).
6. **Hyperparameter tuning**: `RandomizedSearchCV` (40 settings) on HistGradientBoosting, choosing the setting with the smallest train/validation gap among those within 0.005 of the best score.
7. **Evaluation on the untouched test set**: threshold chosen from out-of-fold predictions, bootstrap confidence interval, decile/lift/KS analysis, permutation importance.
8. **Business layer**: value at risk = churn probability × CLTV, with a sensitivity table for call cost and save rate.

## Results

**Model comparison (5-fold CV, PR-AUC)**

| Model | Train | Validation | Gap |
|---|---|---|---|
| HistGradientBoosting | 0.939 | **0.801** | 0.138 |
| LightGBM | 0.973 | 0.792 | 0.181 |
| XGBoost | 0.971 | 0.791 | 0.180 |
| Logistic Regression | 0.791 | 0.770 | 0.021 |
| Linear SVM | 0.791 | 0.768 | 0.023 |
| Random Forest | 0.955 | 0.763 | 0.192 |
| ANN (Keras) | 0.845 | 0.761 | 0.084 |
| Extra Trees | 0.933 | 0.759 | 0.174 |
| Autoencoder + ANN | 0.741 | 0.694 | 0.046 |
| Decision Tree | 0.745 | 0.682 | 0.063 |
| KNN | 0.722 | 0.672 | 0.051 |
| Naive Bayes | 0.635 | 0.629 | 0.005 |

**Tuned HistGradientBoosting**: `max_depth=3, max_iter=150, learning_rate=0.05, min_samples_leaf=100, l2_regularization=2.0`. Overfitting gap reduced from 0.138 to **0.036** (train 0.837, validation 0.801).

**Test set (1,409 customers, never seen during training)**

| Metric | Value |
|---|---|
| PR-AUC | 0.786 (95% CI 0.745–0.827) |
| ROC-AUC | 0.911 |
| Accuracy | 84.1% |
| Precision / Recall / F1 | 0.683 / 0.749 / 0.714 |
| Decision threshold | 0.393 |
| KS statistic | 64.2 |
| Churners caught in top 30% of scores | 76% |

**Top drivers** (permutation importance): Contract type, Number of Referrals, Charge per Tenure, Age, Dependents.

**Business impact**: 662 customers worth contacting; this catches 349 of 374 actual churners (93%) with an estimated net gain of **288,186** (assuming offer cost 200 and 30% save rate; see the sensitivity table in the notebook).

## Repository structure

```
telco-churn-prediction/
├── data/
│   ├── telco.csv                       # raw dataset
│   └── telco_features_88cols.csv       # with engineered features
├── notebooks/
│   └── telco_churn.ipynb               # full analysis
├── outputs/                            # files written by the notebook
├── docs/
│   ├── Group_6_Telecom_Churn_Prediction.pptx
│   ├── Models_and_Libraries.docx
│   └── data_dictionary.xlsx
├── requirements.txt
└── README.md
```

## How to run

```bash
git clone https://github.com/<your-username>/telco-churn-prediction.git
cd telco-churn-prediction
pip install -r requirements.txt
jupyter notebook notebooks/telco_churn.ipynb
```

Run the cells top to bottom. The notebook reads `data/telco.csv` and writes its outputs to `outputs/`.

## Tech stack

Python · pandas · NumPy · scikit-learn · LightGBM · XGBoost · TensorFlow/Keras · SciPy · Matplotlib · Seaborn
